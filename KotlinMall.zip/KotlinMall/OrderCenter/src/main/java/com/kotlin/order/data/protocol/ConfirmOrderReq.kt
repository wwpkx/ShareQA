package com.kotlin.order.data.protocol

/*
    确认订单
 */
data class ConfirmOrderReq(val orderId:Int)
