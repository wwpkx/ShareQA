package com.kotlin.goods.data.protocol

/*
    获取商品详情请求
 */
data class GetGoodsDetailReq(val goodsId: Int)
