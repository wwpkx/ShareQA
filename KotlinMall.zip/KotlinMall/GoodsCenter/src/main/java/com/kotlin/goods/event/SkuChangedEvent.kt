package com.kotlin.goods.event

/*
    SKU变化事件
 */
class SkuChangedEvent
