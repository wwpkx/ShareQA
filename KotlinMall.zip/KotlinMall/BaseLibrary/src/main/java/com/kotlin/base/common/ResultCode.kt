package com.kotlin.base.common

/*
    网络响应码
 */
class ResultCode {
    companion object {
        const val SUCCESS = 0
    }
}
